@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Serve_Local.ps1" -OpenGL
if errorlevel 1 pause
