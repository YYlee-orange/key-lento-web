Windows 本地试玩
把压缩包完整解压后双击 Start_Local.cmd，保留启动窗口。
启动器会在一个独立的 Chrome 或 Edge 配置中用 OpenGL 打开游戏，并保留日常浏览器配置。
