param([switch] $NoBrowser, [switch] $OpenGL)

$ErrorActionPreference = 'Stop'
$webroot = Join-Path $PSScriptRoot 'WebExport'
if (-not (Test-Path -LiteralPath (Join-Path $webroot 'index.html') -PathType Leaf)) {
    throw 'Extract the complete package before starting the local server.'
}

if ($OpenGL -and -not $NoBrowser) {
    $browser = @(
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe"
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe"
        "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
        "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
        "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe"
    ) | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
    if (-not $browser) { throw 'Install Chrome or Edge to run the OpenGL test.' }
}

$mime = @{
    '.html' = 'text/html; charset=utf-8'
    '.js' = 'application/javascript; charset=utf-8'
    '.wasm' = 'application/wasm'
    '.pck' = 'application/octet-stream'
    '.png' = 'image/png'
}
$server = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, 0)
$server.Start()
$url = "http://127.0.0.1:$($server.LocalEndpoint.Port)/"
Write-Host $url
Write-Host 'Keep this window open while playing. Close it to stop the server.'
try {
    if (-not $NoBrowser) {
        if ($OpenGL) {
            $profile = Join-Path ([IO.Path]::GetTempPath()) ('PixelGTA6-OpenGL-' + [Guid]::NewGuid().ToString('N'))
            $browserArgs = @('--use-angle=gl', '--no-first-run', ('--user-data-dir="{0}"' -f $profile), $url)
            Start-Process -FilePath $browser -ArgumentList $browserArgs
        } else {
            Start-Process $url
        }
    }
    while ($true) {
        $client = $server.AcceptTcpClient()
        try {
            $stream = $client.GetStream()
            $stream.ReadTimeout = 2500
            $stream.WriteTimeout = 15000
            $reader = [IO.StreamReader]::new($stream, [Text.Encoding]::ASCII)
            $request = $reader.ReadLine()
            if ($request -notmatch '^(GET|HEAD) /([A-Za-z0-9_.-]*)(?:\?[^ ]*)? HTTP/1\.[01]$') { continue }
            $method = $Matches[1]
            $name = $Matches[2]
            if (-not $name) { $name = 'index.html' }
            $type = $mime[[IO.Path]::GetExtension($name)]
            while ($reader.ReadLine()) {}
            $path = Join-Path $webroot $name
            if (-not $type -or -not (Test-Path -LiteralPath $path -PathType Leaf)) {
                $response = "HTTP/1.1 404 Not Found`r`nContent-Length: 0`r`nConnection: close`r`n`r`n"
                $stream.Write([Text.Encoding]::ASCII.GetBytes($response), 0, $response.Length)
                continue
            }
            $file = [IO.File]::OpenRead($path)
            try {
                $response = "HTTP/1.1 200 OK`r`nContent-Type: $type`r`nContent-Length: $($file.Length)`r`nCache-Control: no-cache`r`nConnection: close`r`n`r`n"
                $stream.Write([Text.Encoding]::ASCII.GetBytes($response), 0, $response.Length)
                if ($method -eq 'GET') { $file.CopyTo($stream) }
            } finally {
                $file.Dispose()
            }
        } catch [IO.IOException] {
            # A speculative connection or a canceled browser request can close early.
        } finally {
            $client.Dispose()
        }
    }
} finally {
    $server.Stop()
}
